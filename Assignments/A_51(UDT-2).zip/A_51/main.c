#include "student.h"

int main()
{
    int i, j, stud_count, sub_count, choice;
    char cont;

    //Getting initial needed details
    printf("Enter no. of Students : ");
    scanf("%d", &stud_count);
    printf("Enter no. of subjects : ");
    scanf("%d", &sub_count);

    Subject subjects[sub_count];
    Student students[stud_count];

    for (i = 0; i < sub_count; i++)
    {
        printf("Enter the name of subject %d : ", i + 1);
        scanf(" %[^\n]", subjects[i].s_name);
    }
    
    do 
    {
        for(i = 0; i < stud_count; i++)
        {
            printf("----------------Enter the student details----------------\n");
            printf("Enter the student Roll no. : ");
            scanf("%d", &students[i].r_no);
            printf("Enter the student %d name : ", students[i].r_no);
            scanf(" %[^\n]", students[i].name);
            for (j = 0; j < sub_count; j++)
            {
                printf("Enter %s mark : ", subjects[j].s_name);
                scanf("%d", &students[i].mark[j]);
            }
            calculate_average_and_grade(&students[i], sub_count);
        }

        printf("---Display Menu---\n");
        printf("1. All student details\n");
        printf("2. Particular Student Detail\n");
        
        printf("Enter your choice : ");
        scanf("%d", &choice);
        if (choice == 1) 
        {
            printf("Roll No.   Name           ");
            for (i = 0; i < sub_count; i++) 
            {
                printf("%-12s", subjects[i].s_name);
            }
            printf("Average     Grade\n");

            for (i = 0; i < stud_count; i++) 
            {
                printf("%-10d %-13s", students[i].r_no, students[i].name);
                for (int j = 0; j < sub_count; j++) 
                {
                    printf("%-12d", students[i].mark[j]);
                }
                printf("%-12.2f %c\n", students[i].avg, students[i].grade);
            }
        } 
        else if (choice == 2) 
        {
            int sub_choice, roll;
            char name[50];
            printf("----Menu for Particular student----\n");
            printf("1. Name.\n2. Roll no.\n");
            
            printf("Enter your choice : ");
            scanf("%d", &sub_choice);
            if (sub_choice == 1) 
            {
                printf("Enter the name of the student : ");
                scanf("%s", name);
                for (i = 0; i < stud_count; i++) 
                {
                    if (strcmp(students[i].name, name) == 0) 
                    {
                        printf("Roll No.   Name           ");
                        for (j = 0; j < sub_count; j++) 
                        {
                            printf("%-12s", subjects[j].s_name);
                        }
                        printf("Average     Grade\n");
                        printf("%-10d %-13s", students[i].r_no, students[i].name);
                        for (j = 0; j < sub_count; j++) 
                        {
                            printf("%-12d", students[i].mark[j]);
                        }
                        printf("%-12.2f %c\n", students[i].avg, students[i].grade);
                        break;
                    }
                }
            } 
            else if (sub_choice == 2) 
            {
                printf("Enter the roll no. of the student : ");
                scanf("%d", &roll);
                for (i = 0; i < stud_count; i++) 
                {
                    if (students[i].r_no == roll) 
                    {
                        printf("Roll No.   Name           ");
                        for (j = 0; j < sub_count; j++) 
                        {
                            printf("%-12s", subjects[j].s_name);
                        }
                        printf("Average     Grade\n");
                        printf("%-10d %-13s", students[i].r_no, students[i].name);
                        for (j = 0; j < sub_count; j++) 
                        {
                            printf("%-12d", students[i].mark[j]);
                        }
                        printf("%-12.2f %c\n", students[i].avg, students[i].grade);
                        break;
                    }
                }
            }
        }
        
        printf("Do you want to continue to display(Y/N) : ");
        scanf(" %c", &cont);
    }while(cont == 'Y' || cont == 'y');
    
    return 0;
}



