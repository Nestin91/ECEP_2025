#ifndef STUDENT_H
#define STUDENT_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define SCORE 100

typedef struct Student
{
    int r_no;
    int mark[10];
    float avg;
    char name[50];
    char grade;
}Student;

typedef struct Subject
{
    char s_name[20];
}Subject;

void calculate_average_and_grade(Student *stud, int sub_count);

#endif