#include "student.h"

void calculate_average_and_grade(Student *stud, int sub_count) 
{
    int i, sum = 0;
    for (i = 0; i < sub_count; i++) 
    {
        sum += stud -> mark[i];
    }
    stud -> avg = (float)sum / sub_count;

    if (stud -> avg >= 90) 
    {
        stud -> grade = 'A';
    }
    else if (stud -> avg >= 80)
    { 
        stud ->grade = 'B';
    }
    else if (stud -> avg >= 70) 
    {
        stud -> grade = 'C';
    }
    else if (stud -> avg >= 60)
    { 
        stud -> grade = 'D';
    }
    else
    {
        stud -> grade = 'F';
    }
}
